from project.teacher import Teacher

obj = Teacher()
print(obj.teach())
print(obj.sleep())
print(obj.get_fired())